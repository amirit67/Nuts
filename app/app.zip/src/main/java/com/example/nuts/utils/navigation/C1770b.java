package com.example.nuts.utils.navigation;

public interface C1770b {
    /* renamed from: a */
    void mo2351a(C1769a c1769a);
}
